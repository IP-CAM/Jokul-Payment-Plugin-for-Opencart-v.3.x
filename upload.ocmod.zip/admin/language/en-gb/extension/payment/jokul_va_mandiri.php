<?php

// Title
$_['heading_title']     = 'Jokul - Mandiri VA';

// Texts
$_['text_jokul_va_mandiri']         = '<a onclick="window.open(\'https://www.doku.com\');"><img src="view/image/payment/doku.png" alt="DOKU" title="DOKU" style="border: 1px solid #EEEEEE;" /><br /></a>';
$_['va_input_label']                = 'Mandiri VA';
$_['text_extension']                = 'Extensions';
$_['text_success']                  = 'Success: You have modified Jokul account details!';
$_['text_edit']                     = 'Edit configuration';

// Entries
$_['entry_status']      = 'Status';

// Button
$_['button_save'] = 'Save';
