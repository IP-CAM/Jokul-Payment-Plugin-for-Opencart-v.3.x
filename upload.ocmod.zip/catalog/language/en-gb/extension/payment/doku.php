<?php
// Text
$_['button_confirm'] = 'Confirm'; 
