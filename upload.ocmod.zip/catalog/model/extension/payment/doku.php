<?php
class ModelExtensionPaymentDOKU extends Model
{
  public function getMethod($address, $total)
  {
    return array();
  }
}
